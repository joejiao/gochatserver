package main

func main() {
	var p_value *int = nil
	*p_value = 1
}
