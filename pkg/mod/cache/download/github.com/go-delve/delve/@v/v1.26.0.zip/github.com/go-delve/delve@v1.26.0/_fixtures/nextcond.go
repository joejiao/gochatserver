package main

var n = 10

func f1(x int) {
}

func main() {
	f1(n)
	f1(n)
	f1(n)
}
