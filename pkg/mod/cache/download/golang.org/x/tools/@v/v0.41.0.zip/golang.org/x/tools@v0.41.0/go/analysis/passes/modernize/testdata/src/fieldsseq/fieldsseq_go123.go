package fieldsseq
